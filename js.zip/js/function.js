//Function
//- fundamental building block in the program
//- subprogram can be used multiple times
//- performs a task or calculates a value

//1. Function declaration 선언
//function name(param1, param2){body...return;}
//one function === one thing
//function is object in JS

//2. Parameters
//premitive Parameters : passed by value
//object Parameters : passed by reference
function changeName(obj) {
  obj.name = 'coder';
}
const oh = { name: 'oh' };
changeName(oh);
console.log(oh);

//3. Default parameters(added in ES6)
function showMessage(message, from = 'unnkown') {
  console.log(message + ' by ' + from);
}
showMessage('hi');

//4. Rest parameters (added in ES6)
function printAll(...args) {
  for (let i = 0; i < args.length; i++) {
    console.log(args[i]);
  }

  for (const arg of args) {
    console.log(arg);
  }
}
printAll('dream', 'coding', 'oh');

//5. local scope
let globalMessage = 'global'; //global variable 전역변수

function printMessage() {
  let message = 'hello'; //local variable 지역변수
  console.log(globalMessage);
  console.log(message);
}
printMessage();

//6. Return a value
function sum(a, b) {
  return a + b;
}
const result = sum(5, 5);
console.log('sum:' + result);

//## callback function using function experssion
function randomQuiz(answer, printYes, printNo) {
  if (answer === 'love you') {
    printYes();
  } else {
    printNo();
  }
}
//anonymous function 익명함수
const printYes = function () {
  console.log('yes');
};

//named function
const printNo = function print() {
  console.log('no');
};
randomQuiz('fuck', printYes, printNo);

//## Arrow function 화살표함수
//always anonymous
const simplePrint = () => console.log('simplePrint');
simplePrint();

//IIFE: Immediately Invoked Function Expression 즉시 호출함수
(function hello() {
  console.log('IIFE');
})();

function calculate(command, a, b) {
  if (command === 'add') {
    return a + b;
  } else if (command === 'multiply') {
    return a * b;
  }
}
const quiz = calculate('multiply', 5, 6);
console.log(quiz);

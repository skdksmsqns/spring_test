//1. String concatenation
console.log('my' + 'cat');
console.log('1' + 2);

//2. Numeric operators
console.log(1 + 1); //add
console.log(1 - 1); //substract
console.log(1 * 1); //divide
console.log(1 / 1); //muliply
console.log(1 % 1); //remainder
console.log(2 ** 3); //exponentiation

//3. Increment and decrement operators
let counter = 2;
const preIncerment = ++counter;
console.log(preIncerment);

//4. Assignment operators 할당
let x = 3;
let y = 6;
x += y;
console.log(x);

//5. comparison operators 비교
console.log(10 < 6);
console.log(10 >= 6);

//6. Logical operators : || (or), && (and), !(not) 논리적

//7. Equlity 평등
const stringFive = '5';
const numberFive = 5;

// == loose equality, with type conversion
console.log(stringFive == numberFive);
console.log(stringFive != numberFive);

// === strict equality,  no type conversion
console.log(stringFive === numberFive);
console.log(stringFive !== numberFive);

//8. Conditional operators : if
// if, else if, else
const name = 'coder';
if (name === 'oh') {
  console.log('hi Oh');
} else if (name === 'coder') {
  console.log('you are amazing coder');
} else {
  console.log('unkwnon');
}

//9. Ternary operators : ? 삼항 조건 연산자
//condition ? value1 : value2;
console.log(name === 'coder' ? 'yes' : 'no');

//10. SWitch operators
//use for multiple if checks
const browser = 'IE';
switch (browser) {
  case 'IE':
    console.log('go away!');
    break;
  case 'Chrome':
    console.log('good');
    break;
  default:
    console.log('same all');
    break;
}

//11. Loops
// while loop, while the condition is truthy, body code is executed.
let i = 3;
while (i > 0) {
  console.log('while:' + i);
  i--;
}

//do while loop, code is executed first, then check the dondition.
do {
  console.log('do while:' + i);
  i--;
} while (i > 0);

//for loop, for(begin; condition; step) 다중 for문 가능
for (i = 3; i > 0; i--) {
  console.log('for:' + i);
}

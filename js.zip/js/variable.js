'use strict';

//Variable, rw(read/write) 변경 가능
//1. let (added in ES6)
//mutable data type
{
  let name = 'oh';
  console.log(name);

  name = 'jung';
  console.log(name);
}

//2. var (don't ever use this!)
//var goisting(move,declaration from bottom to top) 어디에 선언되든 제일 위로 선언을 끌어올려줌
//has no black scope
console.log(age);
age = 5;
var age;

//3. contant,  r(read only) 값을 선언함과 동시에 변경 불가
//favor immutable data type always for a few reasons:
//- securty
//- thread safety
//- reduce human mistakes
const daysInWeek = 7;
const maxNumber = 5;

//4. Variable type
// primitive, single item: Number, string, boolean, null, undefined, symbol
// Object, box container
// function, first-class function
//js는 정수,실수는 number 하나로가능, number따로 선언하지 않아도 가능
const count = 17; //integer
const size = 17.1; //decimal number
console.log('value:' + count + '/ type:' + typeof count);
console.log('value:' + size + '/ type:' + typeof size);

//5. Dynamic typing: dynamically typed language
let text = 'hi';
console.log(text + '/ type:' + typeof text);
text = 1;
console.log(text + '/ type:' + typeof text);
text = '7' + 5;
console.log(text + '/ type:' + typeof text);
text = '8' / '2';
console.log(text + '/ type:' + typeof text);
